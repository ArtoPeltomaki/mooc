package sec.project.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserDetailsService userDetailsService;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
// no real security at the moment
// comment these 2 lines to have the fixed version
        http.authorizeRequests()
                .anyRequest().permitAll();
        
//this was used to have better sequrity
//        http
//            .authorizeRequests()
//                .antMatchers("/h2-console*").denyAll()
//                .antMatchers("/list*").authenticated() 
//                .antMatchers("/update-password*").permitAll() 
//                .antMatchers("/**", "/error*", "/done*", "/form*", "/info*").permitAll()
//                .and()
//            .formLogin()
//                // Next line will make login not work, no idea why
//                //.loginPage("/login")
//                .permitAll()
//                .defaultSuccessUrl("/list", true)
//                .failureUrl("/login-error")
//                .failureForwardUrl("/login-error")
//                .and()
//            // logout syntax here is ok but it just does not work
//            .logout()
//                .permitAll()
//                //.invalidateHttpSession(true)
//                //.clearAuthentication(true)
//                //.logoutSuccessUrl("/login?logout")
//                //.logoutUrl("/logout")
//                .and()
//            .httpBasic()
//                .and()
//            .headers()
//                .frameOptions().sameOrigin()
//                .xssProtection();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}

