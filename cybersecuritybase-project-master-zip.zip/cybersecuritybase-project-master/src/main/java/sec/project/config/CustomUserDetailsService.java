package sec.project.config;

import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private PasswordEncoder passwordEncoder;
        
    private Map<String, String> accountDetails;

    @PostConstruct
    public void init() {
        // this data would typically be retrieved from a database
        this.accountDetails = new TreeMap<>();
//      This is the too obvious password  
//        this.accountDetails.put("ted", "$2a$06$rtacOjuBuSlhnqMO2GKxW.Bs8J6KI0kYjw/gtF0bfErYgFyNTZRDm");
//      A better default password
        this.accountDetails.put("ted", "$2a$10$aUY84hWvMKX93ulYkdyfzeyvv2XCdU6vTaMJS5uOxnijHm2guQzyG");
        //this.accountDetails.put("ted", passwordEncoder.encode("tätäenkerro"));
        //String pw = passwordEncoder.encode("mikäliesalasana");
        //System.out.println(pw);
    }

        
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (!this.accountDetails.containsKey(username)) {
            throw new UsernameNotFoundException("No such user: " + username);
        }

        return new org.springframework.security.core.userdetails.User(
                username,
                this.accountDetails.get(username),
                true,
                true,
                true,
                true,
                Arrays.asList(new SimpleGrantedAuthority("USER")));
    }
    
    //@Autowired
    public Boolean updatePassword(String username, String oldPw, String newPw) {
       UserDetails user = loadUserByUsername(username);
       String currentPw = user.getPassword();
       String oldPwCiph = passwordEncoder.encode(oldPw);
       boolean result = passwordEncoder.matches(oldPwCiph, currentPw);
       if (result) {
           String newPwCiph = passwordEncoder.encode(newPw);
           this.accountDetails.replace(username,newPwCiph);
           return true;
       }
       return false;
    }
}
