package sec.project.controller;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.time;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sec.project.domain.Signup;
import sec.project.repository.SignupRepository;
import org.springframework.ui.Model;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import sec.project.service.CipherService;
import sec.project.config.CustomUserDetailsService;

        
@Controller
public class SignupController {


    
    public boolean isValidEmailAddress(String email) {
        return true;
//        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
//        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
//        java.util.regex.Matcher m = p.matcher(email);
//        return m.matches();
    } 
    
    public boolean nameIsValidName(String name) {
        return true;
//        if ((name.length() < 2) || (name.length() > 15)) {
//            return false;
//        }
//        return ((!name.equals("")) 
//        && (name != null) 
//        && (name.matches("^[a-zA-Z]*$"))); 
    }

    public boolean creditCardNumberValid(String cardNumber) {
        return true;
//        return ((!cardNumber.equals("")) 
//        && (cardNumber != null)
//        && (cardNumber.length() == 4)
//        && (cardNumber.matches("^[0-9]*$"))); 
}
    
    public int errorCount = 0;    

   
   
    @Autowired
    private SignupRepository signupRepository;

    @RequestMapping("*")
    public String defaultMapping() {
        return "redirect:/form";
    }

    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String loadForm() {
        return "form";
    }

    @RequestMapping(value = "/form", method = RequestMethod.POST)
    public String submitForm(@RequestParam String name, @RequestParam String address, @RequestParam String creditcard, HttpServletRequest request) {
        if (isValidEmailAddress(address)) {
            if (nameIsValidName(name)) {
                if (creditCardNumberValid(creditcard)) {
                    String secret = "abc123";
                    String creditcardCiph = CipherService.encrypt(creditcard,secret);
                    //String creditcardOpened = CipherService.decrypt(creditcardCiph,secret);
                    //System.out.println(creditcardOpened);
//                    System.out.println(date() + time() + "New sigup " + name + " " + address + " " + creditcardCiph);
// Comment the unsecuew line and remove comment from the more secure
                    signupRepository.save(new Signup(name, address, creditcard));
//                    signupRepository.save(new Signup(name, address, creditcardCiph));
                    return "done";
                }
                else {
//                    System.err.println(date() + time() + "creditCard incorrect");
                }
            }
            else {
//                System.err.println(date() + time() + "name incorrect");
            }
        }
        else {
//            System.err.println(date() + time() + "eMail incorrect");
        }
        //HttpSession httpSession = request.getSession();
        //Authentication auth = SecurityContextHolder.getContext().getAuthentication();
              
        String sessionId = RequestContextHolder.currentRequestAttributes().getSessionId();
        String ip = request.getRemoteAddr();
//        System.err.println(date() + time() + "user parameter error" + " session: " + sessionId + " ip: " + ip);
//        return "redirect:/error";
        return "form";
    }
    
    @RequestMapping(value = "/list")
    public String listForm(Model model, HttpServletRequest request) {
        errorCount = 0;
        String ip = request.getRemoteAddr();
//        System.out.println(date() + time() + "list of participants displayed " + "ip: " + ip);
        model.addAttribute("participants", signupRepository.findAll());
        return "list";
    }
    
    @RequestMapping(value = "/info")
    public String listInfo(Model model, HttpServletRequest request) {
        errorCount = 0;
        String ip = request.getRemoteAddr();
//        System.out.println(date() + time() + "info of participants displayed " + "ip: " + ip);
        model.addAttribute("participants", signupRepository.findAll());
        return "info";
    }    

}
