package sec.project.controller;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.time;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.ui.Model;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;


import sec.project.config.CustomUserDetailsService;

        
@Controller
public class LoginController {
    
    public int errorCount = 0;    

    @RequestMapping(value = "/login-error")
    public String loginError(HttpServletRequest request, Model model) {
        String ip = request.getRemoteAddr();
//        System.err.println(date () + time() + "failed login" + " ip: " + ip);
        errorCount = errorCount + 1;
//        try {
//            TimeUnit.SECONDS.sleep(errorCount);
//        } catch (InterruptedException ie) {
//            Thread.currentThread().interrupt();
//        }
        return "form";
    }
    
    @RequestMapping(value = "/update-password", method = RequestMethod.POST)
    //@PreAuthorize("hasRole('READ_PRIVILEGE')")
    public String changeUserPassword(@RequestParam String username, @RequestParam String password, @RequestParam String oldPassword, HttpServletRequest request)
    {
        CustomUserDetailsService pwCheck = new CustomUserDetailsService();         
        boolean result = pwCheck.updatePassword(username, password, oldPassword); 
        String ip = request.getRemoteAddr();
        if (result) {
//            System.out.println(date() + time() + "password update" + " ip: " + ip);
            return ("list");        
        }
//        System.err.println(date() + time() + "failed password update" + " ip: " + ip);
        return "error";
    }
    
     
    
    //@RequestMapping(value = "/login", method = RequestMethod.POST)
    //public String loginForm(@RequestParam String username, @RequestParam String password, HttpServletRequest request) {
        // Configuration in SecurityConfiguration.java
    //    request.getSession().setMaxInactiveInterval(1);
        
    //    System.out.println("Login " + username);
    //    return "login";
    //}
    

    
    //@RequestMapping(value="/logout", method = RequestMethod.GET)
    //public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
    //    System.out.println("Logout");
    //    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    //    if (auth != null){    
    //        new SecurityContextLogoutHandler().logout(request, response, auth);
    //    }
    //    return "redirect:/login?logout";//You can redirect wherever you want, but generally it's a good practice to show login screen again.
    //}
    
    
    //no need to add error because it is reserved word
    //@RequestMapping(value = "/error")
    //public String returnError() {
    //    return "error";
    //}  
}
