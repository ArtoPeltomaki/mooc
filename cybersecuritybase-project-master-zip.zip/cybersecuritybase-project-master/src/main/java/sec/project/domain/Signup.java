package sec.project.domain;

import javax.persistence.Entity;
import org.springframework.data.jpa.domain.AbstractPersistable;
import javax.validation.constraints.Size;

@Entity
public class Signup extends AbstractPersistable<Long> {

//    @Size(min = 2, max = 14)
    private String name;
    private String address;
    private String creditcard;

    public Signup() {
        super();
    }

    public Signup(String name, String address, String creditcard) {
        this();
        this.name = name;
        this.address = address;
        this.creditcard = creditcard;
    }

    public String getName() {
        return name;
    }

    public boolean setName(String name) {
        this.name = name;
        return true;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCreditcard() {
        return creditcard;
    }
    
    public void setCreditcard(String creditcard) {
        this.creditcard = creditcard;
    }
    
}
